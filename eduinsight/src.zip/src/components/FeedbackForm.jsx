import React, { useState } from "react";
import { Card, CardContent, TextField, Button, Typography, Rating } from "@mui/material";

// 🔹 Accept selectedCourse as a prop from StudentDashboard
function FeedbackForm({ selectedCourse }) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");

    if (!selectedCourse) {
      setMessage("⚠️ Please select a course before submitting feedback.");
      return;
    }

    try {
      // 🧩 Send feedback data to backend
      const response = await fetch("http://localhost:5000/api/feedback/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          course_id: selectedCourse.course_id, // ✅ dynamically passed
          rating,
          comment,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage("✅ Feedback submitted successfully!");
        setRating(0);
        setComment("");
      } else {
        setMessage("❌ " + data.message);
      }
    } catch (err) {
      console.error("⚠️ Feedback submission failed:", err);
      setMessage("⚠️ Server error, please try again later.");
    }
  };

  return (
    <Card sx={{ maxWidth: 600, m: "40px auto", p: 2 }}>
      <CardContent>
        <Typography variant="h6" gutterBottom>
          Give Feedback for {selectedCourse ? selectedCourse.course_name : "a Course"}
        </Typography>

        {/* ⭐ Rating input */}
        <Typography gutterBottom>Rating:</Typography>
        <Rating value={rating} onChange={(e, newValue) => setRating(newValue)} />

        {/* 💬 Comment box */}
        <TextField
          label="Comment"
          multiline
          rows={3}
          fullWidth
          margin="normal"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />

        {/* 🚀 Submit button */}
        <Button variant="contained" onClick={handleSubmit}>
          Submit Feedback
        </Button>

        {/* 🔔 Status message */}
        {message && (
          <Typography variant="body2" sx={{ mt: 2, color: "gray" }}>
            {message}
          </Typography>
        )}
      </CardContent>
    </Card>
  );
}

export default FeedbackForm;
