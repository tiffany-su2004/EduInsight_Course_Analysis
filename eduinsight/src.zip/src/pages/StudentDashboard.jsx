import React, { useEffect, useState } from "react";
import {
  Box,
  AppBar,
  Toolbar,
  Typography,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Button,
  Grid,
  Card,
  CardContent,
} from "@mui/material";
import FeedbackForm from "../components/FeedbackForm";
import SubmissionsTable from "../components/SubmissionsTable";
import { useNavigate } from "react-router-dom"; // ⚙️ NEW: for logout navigation

const drawerWidth = 220;

function StudentDashboard() {
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [activeSection, setActiveSection] = useState("courses");
  const navigate = useNavigate(); // ⚙️ navigation hook

  // 🧠 Fetch all courses from backend
  useEffect(() => {
    fetch("http://localhost:5000/api/courses/all")
      .then((res) => res.json())
      .then((data) => setCourses(data))
      .catch(() => console.log("⚠️ Failed to fetch courses"));
  }, []);

  // ⚙️ NEW: Logout logic
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    alert("You have been logged out successfully."); // optional
    navigate("/"); // redirect to login
  };

  return (
    <Box sx={{ display: "flex" }}>
      {/* ==================== SIDEBAR ==================== */}
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: drawerWidth,
            boxSizing: "border-box",
            backgroundColor: "#1976d2",
            color: "white",
          },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: "auto" }}>
          <List>
            {/* Sidebar items with highlight */}
            <ListItem
              button
              onClick={() => setActiveSection("courses")}
              sx={{
                backgroundColor:
                  activeSection === "courses" ? "rgba(255,255,255,0.2)" : "transparent",
                "&:hover": { backgroundColor: "rgba(255,255,255,0.3)" },
              }}
            >
              <ListItemText
                primary="Give Feedback"
                primaryTypographyProps={{
                  fontWeight: activeSection === "courses" ? "bold" : "normal",
                  color: "white",
                }}
              />
            </ListItem>

            <ListItem
              button
              onClick={() => setActiveSection("submissions")}
              sx={{
                backgroundColor:
                  activeSection === "submissions"
                    ? "rgba(255,255,255,0.2)"
                    : "transparent",
                "&:hover": { backgroundColor: "rgba(255,255,255,0.3)" },
              }}
            >
              <ListItemText
                primary="My Submissions"
                primaryTypographyProps={{
                  fontWeight: activeSection === "submissions" ? "bold" : "normal",
                  color: "white",
                }}
              />
            </ListItem>
          </List>
        </Box>
      </Drawer>

      {/* ==================== MAIN CONTENT ==================== */}
      <Box component="main" sx={{ flexGrow: 1, bgcolor: "#f9f9f9", p: 3 }}>
        {/* Top Navbar */}
        <AppBar
          position="fixed"
          sx={{
            width: `calc(100% - ${drawerWidth}px)`,
            ml: `${drawerWidth}px`,
            backgroundColor: "#1565c0",
          }}
        >
          <Toolbar>
            <Typography variant="h6" sx={{ flexGrow: 1 }}>
              Student Dashboard
            </Typography>

            {/* ⚙️ UPDATED: logout button works */}
            <Button color="inherit" onClick={handleLogout}>
              Logout
            </Button>
          </Toolbar>
        </AppBar>

        {/* Add space below navbar */}
        <Toolbar />

        {/* ==================== CONDITIONAL RENDERING ==================== */}

        {/* 📘 Available Courses Section */}
        {activeSection === "courses" && (
          <>
            <Typography variant="h5" gutterBottom>
              Available Courses
            </Typography>

            <Grid container spacing={2}>
              {courses.map((course) => (
                <Grid item xs={12} sm={6} md={4} key={course.course_id}>
                  <Card
                    sx={{
                      cursor: "pointer",
                      transition: "0.3s",
                      "&:hover": { boxShadow: 6, transform: "scale(1.02)" },
                    }}
                    onClick={() => setSelectedCourse(course)}
                  >
                    <CardContent>
                      <Typography variant="h6">
                        {course.course_name}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Instructor: {course.instructor_name || "N/A"}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Department: {course.department || "N/A"}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Semester: {course.semester || "N/A"}
                      </Typography>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>

            {selectedCourse && (
              <Box sx={{ mt: 4 }}>
                <Typography variant="h6" gutterBottom>
                  Feedback for {selectedCourse.course_name}
                </Typography>
                <FeedbackForm selectedCourse={selectedCourse} />
              </Box>
            )}
          </>
        )}

        {/* 📄 My Submissions Section */}
        {activeSection === "submissions" && (
          <Box sx={{ mt: 4 }}>
            <SubmissionsTable />
          </Box>
        )}
      </Box>
    </Box>
  );
}

export default StudentDashboard;
