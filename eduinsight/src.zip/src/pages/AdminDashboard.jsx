import React, { useState, useEffect } from "react";
import {
  Box,
  AppBar,
  Toolbar,
  Typography,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Button,
  Card,
  CardContent,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Dialog,
  DialogTitle,
  DialogContent,
  Rating,
} from "@mui/material";

import { useNavigate } from "react-router-dom";

const drawerWidth = 220;

const AdminDashboard = () => {
  const [activeSection, setActiveSection] = useState("students");
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null); // 🔹 NEW
  const [openModal, setOpenModal] = useState(false); // 🔹 NEW
  const navigate = useNavigate();

  // 🧠 Fetch all students with feedback
  const fetchStudentsWithFeedback = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/admin/students/feedbacks");
      const data = await res.json();
      setStudents(data);
    } catch {
      console.log("⚠️ Failed to load students + feedbacks");
    }
  };

  useEffect(() => {
    if (activeSection === "students") fetchStudentsWithFeedback();
  }, [activeSection]);

  // 🧩 Logout
  const handleLogout = () => {
    localStorage.clear();
    alert("Admin logged out successfully.");
    navigate("/");
  };

  // 🔹 Handle modal open/close
  const handleOpenFeedback = (student) => {
    setSelectedStudent(student);
    setOpenModal(true);
  };
  const handleCloseFeedback = () => {
    setOpenModal(false);
    setSelectedStudent(null);
  };

  return (
    <Box sx={{ display: "flex" }}>
      {/* ==================== SIDEBAR ==================== */}
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: drawerWidth,
            boxSizing: "border-box",
            backgroundColor: "#1976d2",
            color: "white",
          },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: "auto" }}>
          <List>
            {[
              { key: "courses", label: "Manage Courses" },
              { key: "students", label: "Manage Students" },
              { key: "instructors", label: "Manage Instructors" },
            ].map((item) => (
              <ListItem
                key={item.key}
                button
                onClick={() => setActiveSection(item.key)}
                sx={{
                  backgroundColor:
                    activeSection === item.key
                      ? "rgba(255,255,255,0.2)"
                      : "transparent",
                  "&:hover": { backgroundColor: "rgba(255,255,255,0.3)" },
                }}
              >
                <ListItemText
                  primary={item.label}
                  primaryTypographyProps={{
                    fontWeight: activeSection === item.key ? "bold" : "normal",
                    color: "white",
                  }}
                />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>

      {/* ==================== MAIN AREA ==================== */}
      <Box component="main" sx={{ flexGrow: 1, bgcolor: "#f9f9f9", p: 3 }}>
        {/* Top Bar */}
        <AppBar
          position="fixed"
          sx={{
            width: `calc(100% - ${drawerWidth}px)`,
            ml: `${drawerWidth}px`,
            backgroundColor: "#1565c0",
          }}
        >
          <Toolbar>
            <Typography variant="h6" sx={{ flexGrow: 1 }}>
              Admin Dashboard
            </Typography>
            <Button color="inherit" onClick={handleLogout}>
              Logout
            </Button>
          </Toolbar>
        </AppBar>

        <Toolbar /> {/* spacing below navbar */}

        {/* ==================== MANAGE STUDENTS ==================== */}
        {activeSection === "students" && (
          <Paper sx={{ p: 2, maxWidth: 900, mx: "auto" }}>
            <Typography variant="h5" gutterBottom>
              Manage Students
            </Typography>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Full Name</TableCell>
                  <TableCell>Email</TableCell>
                  <TableCell>Role</TableCell>
                  <TableCell>Feedback Count</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {students.map((s) => (
                  <TableRow key={s.user_id}>
                    <TableCell>{s.full_name}</TableCell>
                    <TableCell>{s.email}</TableCell>
                    <TableCell>{s.role}</TableCell>
                    <TableCell>{s.feedbacks.length}</TableCell>
                    <TableCell>
                      <Button
                        size="small"
                        variant="outlined"
                        onClick={() => handleOpenFeedback(s)} // 🔹 NEW
                      >
                        View Feedback
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Paper>
        )}

        {/* ==================== MODAL: Student Feedback Details ==================== */}
        <Dialog open={openModal} onClose={handleCloseFeedback} maxWidth="md" fullWidth>
          <DialogTitle>
            Feedback from {selectedStudent?.full_name}
          </DialogTitle>
          <DialogContent dividers>
            {selectedStudent?.feedbacks.length > 0 ? (
              selectedStudent.feedbacks.map((fb) => (
                <Card key={fb.feedback_id} sx={{ mb: 2 }}>
                  <CardContent>
                    <Typography variant="subtitle1">
                      {fb.course_name}
                    </Typography>
                    <Rating value={fb.rating} readOnly />
                    <Typography variant="body2" color="text.secondary">
                      {fb.comment || "No comment provided."}
                    </Typography>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Typography color="text.secondary">
                This student has not submitted any feedback yet.
              </Typography>
            )}
          </DialogContent>
          <Button onClick={handleCloseFeedback}>Close</Button>
        </Dialog>
      </Box>
    </Box>
  );
};

export default AdminDashboard;
