// Import React core
import React from "react";

// Import routing tools from react-router-dom
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

// Import your page components
import Login from "./pages/Login";
import Register from "./pages/Register";
import StudentDashboard from "./pages/StudentDashboard";
import InstructorDashboard from "./pages/InstructorDashboard";
import AdminDashboard from "./pages/AdminDashboard";

// App component — this controls navigation between pages
function App() {
  return (
    // The Router wraps all your routes so React can track URL changes
    <Router>
      {/* Simple navigation links for testing — we'll replace these later with buttons or menus */}
      <nav style={{ padding: 10, background: "#f0f0f0" }}>
        <Link to="/login" style={{ margin: 10 }}>Login</Link>
        <Link to="/register" style={{ margin: 10 }}>Register</Link>
        <Link to="/student" style={{ margin: 10 }}>Student</Link>
        <Link to="/instructor" style={{ margin: 10 }}>Instructor</Link>
        <Link to="/admin" style={{ margin: 10 }}>Admin</Link>
      </nav>

      {/* The Routes component holds all individual Route definitions */}
      <Routes>
        {/* path = URL, element = component to render */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/student" element={<StudentDashboard />} />
        <Route path="/instructor" element={<InstructorDashboard />} />
        <Route path="/admin" element={<AdminDashboard />} />

        {/* Optional: default route */}
        <Route path="*" element={<Login />} />
      </Routes>
    </Router>
  );
}

export default App;
